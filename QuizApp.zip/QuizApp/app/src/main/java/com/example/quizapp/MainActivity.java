package com.example.quizapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    RadioGroup BG1,BG2,BG3,BG4,BG5;
    TextView txtResult;
    int counter = 0;
    RadioButton btnA1,btB1,btC1;
    RadioButton btnA2,btB2,btC2;
    RadioButton btnA3,btB3,btC3;
    RadioButton btnA4,btB4,btC4;
    RadioButton btnA5,btB5,btC5;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        txtResult = (TextView)findViewById(R.id.txtResult);
        btnA1 = (RadioButton) findViewById(R.id.radA);
        btB1 = (RadioButton) findViewById(R.id.radB);
        btC1 = (RadioButton) findViewById(R.id.radC);
        btnA2 = (RadioButton) findViewById(R.id.radA2);
        btB2 = (RadioButton) findViewById(R.id.radB2);
        btC2 = (RadioButton) findViewById(R.id.radC2);
        btnA3 = (RadioButton) findViewById(R.id.radA3);
        btB3 = (RadioButton) findViewById(R.id.radB3);
        btC3 = (RadioButton) findViewById(R.id.radC3);
        btB3 = (RadioButton)findViewById(R.id.radB3);
        btnA4 = (RadioButton) findViewById(R.id.radA4);
        btB4 = (RadioButton) findViewById(R.id.radB4);
        btC4 = (RadioButton) findViewById(R.id.radC4);
        btnA5 = (RadioButton) findViewById(R.id.radA5);
        btB5= (RadioButton) findViewById(R.id.radB5);
        btC5 = (RadioButton) findViewById(R.id.radC5);


        btnA1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(), "Wrong", Toast.LENGTH_SHORT).show();
                counter++;
                txtResult.setText("Result="+counter+"/5");

            }
        });
        btC1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(), "Wrong", Toast.LENGTH_SHORT).show();
                txtResult.setText("Result="+counter+"/5");

            }
        });

        btnA2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(), "Wrong", Toast.LENGTH_SHORT).show();
                txtResult.setText("Result="+counter+"/5");

            }
        });
        btC2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(), "Wrong", Toast.LENGTH_SHORT).show();
                txtResult.setText("Result="+counter+"/5");

            }
        });

        btnA3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(), "Wrong", Toast.LENGTH_SHORT).show();
                txtResult.setText("Result="+counter+"/5");

            }
        });
        btC3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(), "Wrong", Toast.LENGTH_SHORT).show();
                txtResult.setText("Result="+counter+"/5");

            }
        });
        btnA4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(), "Wrong", Toast.LENGTH_SHORT).show();
                txtResult.setText("Result="+counter+"/5");

            }
        });
        btB4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(), "Wrong", Toast.LENGTH_SHORT).show();
                txtResult.setText("Result="+counter+"/5");

            }
        });

        btnA5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(), "Wrong", Toast.LENGTH_SHORT).show();
                txtResult.setText("Result="+counter+"/5");

            }
        });
        btC5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(), "Wrong", Toast.LENGTH_SHORT).show();
                txtResult.setText("Result="+counter+"/5");

            }
        });
        btB1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(), "Correct", Toast.LENGTH_SHORT).show();
                counter++;
                txtResult.setText("Result="+counter+"/5");

            }
        });
        btB2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(), "Correct", Toast.LENGTH_SHORT).show();
                counter++;
                txtResult.setText("Result="+counter+"/5");

            }
        });
        btB3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(), "Correct", Toast.LENGTH_SHORT).show();
                counter++;
                txtResult.setText("Result="+counter+"/5");
            }
        });

        btC4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(), "Correct", Toast.LENGTH_SHORT).show();
                counter++;
                txtResult.setText("Result="+counter+"/5");
            }
        });
        btB5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(), "Correct", Toast.LENGTH_SHORT).show();
                counter++;
                txtResult.setText("Result="+counter+"/5");
            }
        });

    }
}